package com.collection.service;

import com.collection.domain.CollectionReviewVO;

public interface ReplyService {
	
	public int register(CollectionReviewVO reviewVO);
	

}
