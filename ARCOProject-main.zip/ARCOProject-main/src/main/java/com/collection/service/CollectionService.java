package com.collection.service;

import com.collection.domain.CollectionVO;

public interface CollectionService {
	
	public void insert(CollectionVO collection);
	public void insertOthers(CollectionVO collection);
	
}
