package com.collection.mapper;

import com.collection.domain.CollectionReviewVO;

public interface ReplyMapper {
	
	
	public int insert(CollectionReviewVO vo);
	
	public CollectionReviewVO read(long seq);
	
	public int delete(long seq);
	
	public int update(CollectionReviewVO vo);
	
}
