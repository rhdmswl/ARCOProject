var heading = document.querySelector('#heading');
heading.onclick = function () {
  heading.style.color = "red";
}  